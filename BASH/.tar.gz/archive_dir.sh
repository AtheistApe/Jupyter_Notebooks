#!/bin/bash
ARCHIVE_DIR="./archives"
echo "Executing script: /bin/bash"
echo "Checking if archive directory already exists. If not, create it."

if [ ! -d  ]
then
    echo "Making directory ."
    mkdir 
else
    echo " already exists."
fi

echo "Archiving directory: "

# Create an archive of the current directory.
tar cf .tar.gz ./
